/*
assign1a.cpp
Name: Lukus Hendrix
CSCI241
Z1761354
*/

#include <iostream>
#include <fstream>
#include <iomanip>
#include <string>
#include <array>
#include <cctype>

using std::cout;
using std::cin;
using std::string;
using std::to_string;
using std::endl;
using namespace std;

 
int convertNumberOfSum(int sum);

int charToNum(char ch);


int returnFunction(string s);

void getTrait(string  );



int main()
{
	string choice;
	string name;
        string ch;
do  {
      cout << "Numerology Program " << endl;
                cout << "\nEnter a name :  ";
                getline(cin, name);
                 getTrait(name) ;

                cout <<  "\nAnother Name? Y or N? " <<  endl;
                getline(cin, choice);
}
while( choice == "Y" || choice == "y");



return  0;
}


int charToNum(char ch)

{

if (isalpha( ch))
return toupper(ch) -'A' +1;
if (isdigit( ch))
        return ch -'0';
else
        return 0;
}



int returnFunction(string s)
{
int sum=0;

for(size_t i=0; i<s.length(); i++)
{
        sum = sum+ charToNum(s[i]);
}
return sum;
}


void getTrait(string name)
{
 string s = name;

int sum;

sum = returnFunction(s);

        switch(sum)
		{

        case 0: cout << " emptiness, nothingness, blank";
        break;
  		case 1: cout << "independence, loneliness, creativity, originality, dominance, leadership, impatience";
        break;
        case 2: cout << "quiet, passive, diplomatic, co-operation, comforting, soothing, intuitive, compromising, patient";
        break;
        case 3: cout << "charming, outgoing, self expressive, extroverted, abundance, active, energetic, proud";
        break;
        case 4: cout << "harmony, truth, justice, order discipline, practicality";
        break;
        case 5: cout << "new directions, excitement, change, adventure";
        break;
        case 6: cout << "love, harmony, perfection, marriage, tolerance, public service";
        break;
        case 7: cout << "spirituality, completeness, isolation, introspection";
        break;
        case 8: cout << "organization, business, commerce, new beginnings";
        break;
        case 9: cout << "romantic, rebellious, determined, passionate, compassionate";
        break;
        case 11: cout << "idealism, visionary, inspirational";
        break;
       case 12:  cout << "perfectionist, discriminating";
        break;
        case 22: cout << "builder, leader, humanitarian, practical, honest";
        break;
		default:

			sum = convertNumberOfSum(sum); 
			s = to_string(sum);
			getTrait(s); 


		}
}

		int convertNumberOfSum(int sum)
		{
			int result = 0;
			while(sum!=0)
			{
				result += sum% 10;
				sum = sum / 10;
			}
			return result;

			}

