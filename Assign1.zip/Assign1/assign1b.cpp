#include <iostream>
#include <string>
#include<array>
#include <cctype>
#include <iomanip>
#include <fstream>

using namespace std;


int convertNumofSum(int);

int charToNum(char );

int returnFunct(string );

void getTrait(string) ;

int main()
{

string name;
string choice;
string ch;

do {
	cout << "please enter a name. " << endl;
		getline( cin, name);
		getTrait(name);
		cout << endl;
		//cout << convertNumofSum(sum);
		cout << "\nAnother Name? Y or N" << endl;
		getline(cin, choice);
}
		while(choice == "Y" || choice == "y");

return 0;
}



int charToNum(char ch)
{

if (isalpha(ch))
 return toupper(ch) -'A'+1;

if(isdigit(ch))
 return  ch -'0';

else return 0;

}

int returnFunction(string str)
{
int sum = 0;

for(size_t i = 0; i < str.length(); i++)
{
	sum = sum + charToNum(str[i]);
}
	return sum;

}


    int convertNumofSum(int sum)
        {

        int result = 0;
        while(sum != 0)
        {
                result += sum % 10;
                sum = sum / 10;
        }
        return result;
        }



void getTrait(string name)
{
string str = name;

int sum;

sum = returnFunction(str);

	switch(sum)
	{

	  case 0: cout << " emptiness, nothingness, blank";
        break;
                case 1: cout << "independence, loneliness, creativity, originalit";
        break;
        case 2: cout << "quiet, passive, diplomatic, co-operation, comforting, so";
        break;
        case 3: cout << "charming, outgoing, self expressive, extroverted, abunda";
        break;
        case 4: cout << "harmony, truth, justice, order discipline, practicality";
        break;
        case 5: cout << "new directions, excitement, change, adventure";
        break;
        case 6: cout << "love, harmony, perfection, marriage, tolerance, public s";
        break;
        case 7: cout << "spirituality, completeness, isolation, introspection";
        break;
        case 8: cout << "organization, business, commerce, new beginnings";
        break;
        case 9: cout << "romantic, rebellious, determined, passionate, compassion";
        break;
        case 11: cout << "idealism, visionary, inspirational";
        break;
       case 12:  cout << "perfectionist, discriminating";
        break;
        case 22: cout << "builder, leader, humanitarian, practical, honest";
        break;
                default:


		sum = convertNumofSum(sum);
		str = to_string(sum);
		getTrait(str);
		cout << sum << endl;

	}

}

/*
	int convertNumofSum(int sum)
	{

	int result = 0;
	while(sum != 0)
	{
		result += sum % 10;
		sum = sum / 10;
	}
	return result;
	}
*/
