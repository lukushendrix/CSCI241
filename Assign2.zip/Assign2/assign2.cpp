# include <iostream>
#include "BookStore.h"
using namespace std;




int main()
{
	BookStore store("bookdata");
	store.print();

	store.processOrders("orders.txt");
	store.print();

return 0;
}
