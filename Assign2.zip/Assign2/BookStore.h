#ifndef BOOKSTORE_H
#define BOOKSTORE_H
#include <fstream>
#include "Book.h"



class BookStore
{
private:

		 Book BookArray[30];
		int BookQuant;


public:
	BookStore();
	BookStore(const char* file);
	void print();
	void sortByISBN();
	void processOrders(const char*);
	int searchForISBN(char*);


};



#endif
