/***********************************************************
CSCI 241 - Assignment 8 - Fall 2016

Progammer: Luke Hendrix
Z-ID: Z1761354
Section: 3
TA:  Karthik Kondagalla
Date Due: November 22, 2016

Purpose: This H file merges the sorted subvector items to establish
	 a sorted list.
************************************************************/



#ifndef MERGESORT_H
#define MERGESORT_H


/***************************************************************
Prototypes
Use: Specifies method's and function's for compiler use.

***************************************************************/

template <class T>
void mergeSort(vector<T>& set, bool (*compare)(const T&, const T&));

template <class T>
void mergeSort(vector<T>& set, int, int , bool (*compare)(const T&, const T&));

template <class T>
void merge(vector<T>& set, int low, int mid, int high, bool (*compare)(const T&, const T&));


/***************************************************************
mergeSort
Use: Calls a recursive merge sort function, passing it the vector,
the subscript of the first element which is 0 and last that is  set.size() -1.

Parameters: 1. vector<T>& set: Reference to a vector containing items to sort.
            2. *compare: A pointer to a comparison function used to compare
               to items of the template type T.
Returns: void,  nothing
****************************************************************/

template <class T>
void mergeSort(vector<T>& set, bool (*compare)(const T&, const T&))
{
mergeSort(set, 0, set.size()-1, compare);
}

/***************************************************************
mergeSort
Use: A recursive function that divides a vector into two subvectors
     sorts and merges the two sorted subvectors. Adds together the high
     and low values, divides them to get the average and sets it to mid.
     Then combines them together.

Parameters: 1. vector<T>& set: Reference to a vector containing items to sort.
            2. low: An integer that holds the lower numbers of the subvector.
            3. high: An integer that holds the higher numbers of the subvector.
            4. *compare: A pointer to a comparison function used to compare
               to items of the template type T.
Returns: void,  nothing
****************************************************************/


template <class T>
void mergeSort(vector<T>& set, int low, int high, bool (*compare)(const T&, const T&))
{
int mid;

   if (low < high)
      {
      mid = (low + high) / 2;


      mergeSort(set, low, mid, compare);
      mergeSort(set, mid+1, high, compare);

      merge(set, low, mid, high, compare);
      }

}

/***************************************************************
merge

Use: This function merges two already sorted subvectors by using
a while loop that uses a temp variable to store the low, mid and high
items and  loops through from highest to lowest.

Parameters: 1. vector<T>& set: Reference to a vector containing items to sort.
            2. low: An integer that holds the lower numbers of the subvector.
	    3. mid: An integer that holds the middle number of the subvector.
            4. high: An integer that holds the higher numbers of the subvector.
            5. *compare: A pointer to a comparison function used to compare
               to items of the template type T.
Returns: void,  nothing
****************************************************************/


template <class T>
void merge(vector<T>& set, int low, int mid, int high, bool (*compare)(const T&, const T&))
{

   vector<T> temp(high - low + 1);

   int i = low;
   int j = mid+1;
   int k = 0;


   while (i <= mid && j <= high)
      {
      if (compare(set[j],  set[i]))
         {
        temp[k] = set[j];
         set[j++];
         set[k++];
         }
      else
         {
         temp[k] = set[i];
         set[i++];
         set[k++];
         }
      }

   // Copies over any remaining elements of left subvector
   while (i <= mid)
      {
	temp[k] = set[i];
	set[i++];
        set[k++];
      }

   // Copies over any remaining elements of right subvector
   while (j <= high)
      {
	temp[k]= set[j];
        set[j++];
        set[k++];
      }

   // Copies merged elements back into original vector
   for (i = 0, j = low; j <= high; i++, j++)
	set[j] = temp[i];



}


#endif
