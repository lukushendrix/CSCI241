/***********************************************************
CSCI 241 - Assignment 6 - Fall 2016

Progammer: Lukus Hendrix
Z-ID: z1761354
Section: 3
T.A: Karthik Kondagalla
Date Due: November 04, 2016

Purpose: This program creates and implements a class to reprsent
the Queue ADT using an array based data structure.

************************************************************/



#include <iostream>
#include <iomanip>
#include "Queue.h"
#include <stdexcept>

using std::out_of_range;
using namespace std;


/*******************************************************
This class has a defualt constructor that takes no arguments.
The constructor sets the queue size and capacity to 0 and sets
the queue array pointer to nullptr. The queue  front is initialized to 0
and the queue back is inistialized to the queue capacity
and is -1.
*******************************************************/

Queue::Queue()
{
queueCap = 0;
queueSize = 0;
queueArr = nullptr;
qFront = 0;
qBack = queueCap - 1;
}

/*********************************************************
This is the destructor that deletes the dynamic memory
for the queue array.

*********************************************************/
Queue::~Queue()
{
delete[] queueArr;
}

/*********************************************************
This is the copy constructor, it intitializes a new queue
capacity for the queue array. This copies the contents of the
entire array.
*********************************************************/

Queue::Queue(const Queue& other)
   {
   queueCap = other.queueCap;
   queueSize = other.queueSize;
   queueArr = new int[queueCap];

   for (size_t i = 0; i < queueCap; ++i)
      queueArr[i] = other.queueArr[i];

   qFront = other.qFront;
   qBack = other.qBack;
   }

/*********************************************************
This is the assignment operator that's overloaded to allow
one queue to be assigned to another. This also copies the contents
of the entire array. It returns *this.

*********************************************************/


Queue& Queue::operator=(const Queue& other)
{

if( queueArr == other.queueArr )

	return *this;
else
queueCap = other.queueCap;
queueSize = other.queueSize;
qFront = other.qFront;
qBack = other.qBack;


	if(queueCap == 0)
        queueArr = nullptr;
	else
        queueArr = new int [other.queueCap];
	if(other.queueCap != 0)
	{
	for(unsigned int i = 0; i < other.queueCap; i++)
		{
        queueArr[i] = other.queueArr[i];
		}
	}

return *this;
}

/*********************************************************
This is the output operator that is overloaded so that the
queue can be printed in standard output. This operator uses
ostream so it required to be a friend.

*********************************************************/



ostream& operator<<(ostream& lhs, const Queue &rhs)
{
        size_t current, i;

for (current = rhs.qFront, i = 0; i < rhs.queueSize; ++i)
   {
   // Print's the queue element at subscript i
   lhs << rhs.queueArr[current] << ' ';

   // Increment i, and cycles to the front
   current = (current + 1) % rhs.queueCap;
   }
        return lhs;
}

/*********************************************************
This method takes no arguments and returns nothing. It
sets the queue front and size back to 0 and re-initializes
the queue back to capacity -1.

*********************************************************/


void Queue::clear()
{
queueSize = 0;
qFront = 0;
qBack = queueCap - 1;

}

/*********************************************************
This method takes no arguments and returns size_t queue capacity.

*********************************************************/

size_t Queue::capacity() const
{
	return queueCap;
}

/*********************************************************
This method takes no arguments and returns a booean value
of true if the size is 0 or just returns false.

*********************************************************/


bool Queue::empty()const
{
	if(queueSize == 0)
	return true;
else
	return false;
}

/*********************************************************
This method takes no arguments and returns the queue size
of size_t.

*********************************************************/

int Queue::size() const
{
	return queueSize;

}

/*********************************************************
This method takes no arguments and returns an integer. If
the queue is empty this method will throw an error exception.
or else it will return the front element of the queue array.

*********************************************************/


int Queue::front()const
{
if (empty())
	throw underflow_error("queueflow on front()");

return queueArr[qFront];

}

/*********************************************************
This method takes no arguments and returns an integer. If
the queue is empty this method will throw an error exception.
or else it will return the back element of the queue array.

*********************************************************/


int Queue::back()const
{
if(empty())
	throw underflow_error("queueflow on back()");

return queueArr[qBack];
}

/*********************************************************
This method takes an integer argument which is the item to
insert into the queue. If the queue is full this method will call
the reserve method to increase the capacity of the queue array.
If the capacity of the queue is 0, it will pass a new capacity
of 1 to the reserve method. Or else it will pass a new capacity of
twice the current queue capacity to the reserve method.

*********************************************************/


void Queue::push(int nItem)

{
if (queueSize == queueCap)
   {
   if (queueCap == 0)
      reserve(1);
   else
      reserve(queueCap * 2);
   }

qBack = (qBack + 1) % queueCap;
queueArr[qBack] = nItem;
++queueSize;

}

/*********************************************************
This method takes no arguments and returns a void. If the
queue is empty, this method will throw an underflow error
message. Or else, this will increment the queue front subscript
to remove the front item in the queue array. Then the queue
size decrements by 1.

*********************************************************/


void Queue::pop()
{
if(empty())
{
	throw underflow_error("queueflow on pop");

}
	else
qFront = (qFront + 1) % queueCap;
--queueSize;
}

/*********************************************************
This method takes an unsigned integer argument which will be the
new capacity to allocate for the queue array. This returns
nothing. This reserves additional capacity for the queue array
so it can equal the new capacity passed in.

*********************************************************/


void Queue::reserve(size_t n)
	{
	if (n > queueCap)
	{
	int* tempArray = new int[n];

	int current = qFront;
	for (size_t i = 0; i < queueSize; i++)
	 {
	tempArray[i] = queueArr[current];
	current = (current + 1) % queueCap;
	 }

	queueCap = n;
	qFront = 0;
	qBack = queueSize - 1;
	delete[] queueArr;
	queueArr = tempArray;
	}
}






