/***********************************************************
CSCI 241 - Assignment 6 - Fall 2016

Progammer: Lukus Hendrix
Z-ID: z1761354
Section: 3
TA: Karthik Kondagalla
Date Due: Nov 04, 2016

Purpose: This is the Queue.h header file which creates the Queue class.
This also implements a friend function to associate with the Queue class.
The operators help establish operator overloading and therefore need iostream.
This creates a class Queue ADT using the array.
************************************************************/



#ifndef VECTORN_H
#define VECTORN_H

#include <iostream>
using namespace std;


class Queue
{

friend ostream& operator<<(ostream&, const Queue&);





public:

Queue();

~Queue();

Queue(const Queue& other);

Queue& operator=(const Queue& other);

void clear();

int size() const;

size_t capacity() const;

bool empty() const;

int front() const;

int back() const;

void push(int);

void pop();

void reserve(size_t );

private:

int *queueArr;

size_t queueCap;

size_t queueSize;

int qBack;

int qFront;





};

#endif

