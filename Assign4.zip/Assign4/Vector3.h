/***********************************************************
CSCI 241 - Assignment 4 - Fall 2016

Progammer: Lukus Hendrix
Z-ID: z1761354
Section: 3
TA: Karthik Kondagalla
Date Due: October 18, 2016

Purpose: This is the Vector.h header file which creates the Vector3 class.
This also implements friend functions to associate with the Vector3 class.
The opertators help establish operator overloading and therefore need iostream.

************************************************************/

#ifndef VECTOR3_H
#define VECTOR3_H

#include <iostream>
using namespace std;


/***********************************************************
The insertion operator is used to overload vector3
sending it to standard output. The addition operator is used to overload and
add components of the operands. The subtration operator is used to
compute the difference of the operands. Finally the multiplication
operator is also used to overload and multiply the operands.
These are all declared as friends to class Vector3.
***********************************************************/


class Vector3
{

friend ostream& operator<<(ostream&, const Vector3&);

friend Vector3 operator*(float, const Vector3&);

friend Vector3 operator+(const Vector3&, const Vector3&);

friend Vector3 operator-(const Vector3&, const Vector3&);

/***********************************************************
Notice, in public construstor Vector3 uses 3 double arguments and
creates a defualt argument equaling to 0.
***********************************************************/


public:

Vector3(double = 0, double = 0, double = 0);

float operator*(const Vector3&)const;

Vector3 operator*(float)const;

double& operator[](int);

double operator[](int)const;

bool operator==(const Vector3&)const;



private:

double vector[3];

};
#endif

