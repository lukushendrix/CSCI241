/*********************************************************************
   PROGRAM:    CSCI 241 Assignment 3
   PROGRAMMER: Lukus Hendrix
   LOGON ID:   Z1761354
   DUE DATE:   due date
   TA NAME:    Karthik Kondagalla
   SECTION:    3
   FUNCTION:   This program opens and executes Verifier.cpp and Verifier.h
		in the main function. The main function also retrieves data
		for the sudoku grid.

*********************************************************************/

#include <iostream>
#include <string>
#include "Verifier.h"

using std::cout;
using std::endl;
using std::string;

#define NUM_FILES 7

int main()
   {
	 Verifier v;
   string fileName;

   cout << "Sudoku Verifier\n";

   for (int i = 1; i <= NUM_FILES; i++)
      {
      cout << endl;

      // Construct file pathname
      fileName = string("/home/turing/t90kjm1/CS241/Data/Fall2016/Assign3/solution") 
        + (char)('0' + i) + ".txt";

      // Read the solution file as input
      v.readGrid(fileName.c_str());

      // Print the Sudoku grid
      v.printGrid();

      // Verify whether or not the solution is correct
      if (v.verifySolution())
         cout << "\nThis is a valid Sudoku solution\n";
      else
         cout << "\nThis is not a valid Sudoku solution\n";
      }

   return 0;

}
