/*********************************************************************
   PROGRAM:    Verifier.h  Assignment 3
   PROGRAMMER: Lukus Hendrix
   LOGON ID:   Z1761354
   DUE DATE:   10/04/16
   TA Name:    Karthik Kondagalla
   SECTION:    3
   FUNCTION:   This program is a header file that had a class
and sets the private and public variables for the sudoku grid for Verifier.cpp
*********************************************************************/


#ifndef VERIFIER_H
#define	VERIFIER_H



class Verifier
{
public:
Verifier();
void readGrid(const char*);
void printGrid();
bool verifySolution();

private:

int Grid[9][9];


};

#endif
