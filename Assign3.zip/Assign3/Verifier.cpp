/*********************************************************************
   PROGRAM:    CSCI 241  Verifier.cpp Assignment 3
   PROGRAMMER: Lukus Hendrix
   LOGON ID:   Z1761354
   DUE DATE:   10/04/16
   SECT NUMBER: 3
   TA NAME:    Karthik Kondagalla
   FUNCTION:   This program checks and prints the Verifier Solution to
               the main function. This program loops through the sudoku
		grid's columns and rows to check if each sudoku is valid. 
*********************************************************************/



#include  <iostream>
#include <iomanip>
#include <fstream>
#include <cstdlib>
#include "Verifier.h"

using namespace std;

/*********************************************************************
   This default constructor calls the Verifier class as an object and allows
the sudoku grid to have a 9x9 columns and row, setting them to zero.
*********************************************************************/  


Verifier::Verifier()
{
for(int col = 0; col <= 8; col++)
{
	for(int row = 0; row <= 8; row++)
{
		Grid[col][row] = 0;
}
}
}

/*********************************************************************
   The readGrid method opens a scope to Verifier.h. Then points to an array
 of characters that contain the name of a file to utilize and use as input.
 It opens the file that contains the sudoku grid for later utilization in
the verifier solution.
*********************************************************************/


void Verifier::readGrid(const char* fileName)
{
ifstream inFile;
	inFile.open(fileName);
	if(!inFile)
{
	cout << "File cannot open. " << endl; 
	exit(-1);
}

for(int col = 0; col <= 8; col++)
{
        for(int row = 0; row <= 8; row++)
{
          inFile >>  Grid[col][row];
}

}
	inFile.close();
}


/********************************************************************
   The printGrid method takes no arguments and does not return anything.
This method is for printing purposes only and outputs 9 rows and 9 columns
the same way it appears on the input file.
*********************************************************************/


void Verifier::printGrid()
{
for(int col = 0; col <= 8; col++)
{
        for(int row = 0; row <= 8; row++)
{
          cout <<  Grid[col][row]<< " ";
}
cout << endl;

}
}

/*********************************************************************
   The verifySolution method takes no arguments; however, it returns a
Boolean value. It will loop through 9 columns and 9 rows, checking true
for a valid solution and false for an invalid solution. This will then
loop through 9 subgrids each 3 by 3 examining each value.

*********************************************************************/

bool Verifier::verifySolution()
{
for(int row= 0; row <9; row++)
{bool found[9]={false};
	for (int col = 0; col< 9; col++)
{
		found[Grid[row][col]-1]=true;
}
	for(int i=0; i <9; i++)
	if (found[i]==false)
{
	return false;
	}
}


for(int col= 0; col <9; col++)
{bool found[9]={false};
	for (int row=0; row < 9; row++)
{
	found[Grid[row][col]-1]=true;
}
		for(int i=0; i <9; i++)
{
		if (found[i]==false)
{
			return false;
	}
}


for(int row=0; row < 3 ; row++)//This checks the 3 by 3 subgrid for rows and columns
{
	for(int col=0; col < 3; col++)
	{	bool found[9]={false};
		for(int subrow=row*3; subrow < row*3+3; subrow++)
	{
			for(int subcol=col*3; subcol < col*3+3; subcol++)
			{
			found[Grid[subrow][subcol]-1]=true;
			}
		}
			for(int i=0 ;i < 9; i++)
			{
			if(found[i]==false)
			return false;
			}
		}
	}
	return true;

}
return 0;
}

