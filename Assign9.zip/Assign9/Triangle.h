#ifndef TRIANGLE_H
#define TRIANGLE_H


class Trianlge public: Shape
{
private:
int height;
int base;

public:

Triangle(string, int, int )

virtual void print();

virtual double get_area();

};

#endif
