#ifndef CIRCLE_H
#define CIRCLE_H
using namespace std;


class Circle public: Shape
{
private:

int radius;

public:
Circle(string, int );

virtual void print();

virtual double get_area();

};

#endif
