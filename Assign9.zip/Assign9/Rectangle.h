#ifndef RECTANGLE_H
#define RECTANGLE_H

class Rectangle public: Shape
{
private:
int height;
int width;

public:

Rectangle(string, int, int);


virtual void print();

virtual double get_area();

};

#endif
