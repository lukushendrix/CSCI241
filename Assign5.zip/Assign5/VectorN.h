/***********************************************************
CSCI 241 - Assignment 5 - Fall 2016

Progammer: Lukus Hendrix
Z-ID: z1761354
Section: 3
TA: Karthik Kondagalla
Date Due: October 27, 2016

Purpose: This is the VectorN.h header file which creates the VectorN class.
This also implements friend functions to associate with the VectorN class.
The operators help establish operator overloading and therefore need iostream.

************************************************************/

#ifndef VECTORN_H
#define VECTORN_H

#include <iostream>
using namespace std;

class VectorN
{

friend ostream& operator<<(ostream&, const VectorN&);

friend VectorN operator*(float, const VectorN&);


/******************************************************
These are the prototypes in public via constructor and
default constructor/ destructor.

******************************************************/


public:

VectorN();

VectorN(const double*, size_t);

VectorN(const VectorN& other);

VectorN operator+(const VectorN&)const;

VectorN operator-(const VectorN&)const;

~VectorN();

VectorN& operator=(const VectorN& other);

size_t size() const;

double at(int sub) const;

double& at(int sub);

void clear();

float operator*(const VectorN&)const;

VectorN operator*(float)const;

double& operator[](int);

double operator[](int)const;

bool operator==(const VectorN&)const;

/**************************************************
There are two private variables. The first one is a
pointer to a double array. The second variable data
type is size_t and is called vectorCapacity.

***************************************************/

private:

double *vectorArr;

size_t vectorCapacity;
 

};
#endif

