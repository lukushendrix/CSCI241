#include <iostream>
#include <iomanip>

#include "Complex.h"

using std::cout;
using std::endl;

Complex::Complex()
{
real = 0;
imag = 0;
}

Complex::Complex( int newReal, int newImag )
{
real = newReal;
imag = newImag;
}

Complex Complex::add( int addReal, int addImag )
{
Complex result;

result.real = real + addReal;

result.imag = imag + addImag;

return result;
}

void Complex::print()
{
cout << "(" << real << ", " << imag << ")" << endl;
}




