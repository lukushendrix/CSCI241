/***********************************************************
CSCI 241 - Assignment 5 - Fall 2016

Progammer: Lukus Hendrix
Z-ID: z1761354
Section: 3
T.A: Karthik Kondagalla
Date Due: October 27, 2016

Purpose: This program illustrates dynamic memory allocation
and implements operator overloading. This program manipulates N
dimensional array vectors for floating point numbers
associated with as many and any N directions.

************************************************************/

#include <iostream>
#include <iomanip>
#include "VectorN.h"
#include <stdexcept>

using std::out_of_range;
using namespace std;

/*******************************************************
This is the default constructor of VectorN and it initializes
the vectorArr to a new object called nullptr. This also initializes
the vectorCapacity to 0.

********************************************************/

VectorN::VectorN()
{
	vectorCapacity = 0;
	vectorArr = nullptr;
}
/**************************************************
This is the destructor that clears the allocated data
when called.
***************************************************/
VectorN::~VectorN()
{
	clear();
}

/*****************************************************
This is the method for the destructor and returns nothing
which is a void. This is used for the destructor to clear
allocated memory.
*****************************************************/
void VectorN::clear()
{
	delete[]vectorArr;
	vectorArr = nullptr;
	vectorCapacity = 0;

}

/*************************************************************
This constructor initializes a new VectorN object to the values
stored int the array values. This initializes n as a new object and
then uses an if statement to see if "n" is equal to 0 to allocate
it as nullptr. Otherwise, it assigns the vector capacity to the vector
array and loops through the values to assign them.

*************************************************************/

VectorN::VectorN(const double values[], size_t n)
{
	vectorCapacity = n;
	if(n == 0)
	{
		vectorArr = nullptr;
	}
	else
	vectorArr = new double[vectorCapacity];

	for(size_t i = 0; i < n; i++)
	{
	vectorArr[i] = values[i];
	}
}

/******************************************************
This returns the size of the vector, which is equal to the
vector capacity.
******************************************************/

size_t VectorN::size() const
{
return vectorCapacity;
}

/***************************************************
This is a copy constructor that initializes a new VectorN
object to the same capacity and array contents as the existing
VectorN object "other."
***************************************************/

VectorN::VectorN(const VectorN& other)
{

	 vectorCapacity = other.vectorCapacity;

	 if (other.vectorCapacity == 0)
	 {
		 vectorArr = nullptr;
	 }
	 else
		 vectorArr = new double[other.vectorCapacity];

	 for(size_t i = 0 ; i < other.vectorCapacity; i++ )
	 {
		 vectorArr[i] = other.vectorArr[i];
	 }

}
/********************************************************
The addition operator is overloaded to take two VectorNs
and return a VectorN overloaded into the object named res.
The method takes any content thats in the array and adds
the values.
********************************************************/

VectorN VectorN::operator+(const VectorN& rhs)const
{
	VectorN res;

	if(vectorCapacity <= rhs.vectorCapacity	)
		res.vectorCapacity = vectorCapacity;
	else
		res.vectorCapacity = rhs.vectorCapacity; 

	res.vectorArr = new double[res.vectorCapacity];

	for(size_t i=0; i < res.vectorCapacity; i++)
	{
	res.vectorArr[i]= vectorArr[i] + rhs.vectorArr[i];
	}
	return res;
}


/********************************************************
Illustrated by the method above, likewise, the subtraction operator
is overloaded to take two VectorNs and return a VectorN overloaded
into the object named res. The method takes any and all content
in the array and subtracts the values.
********************************************************/


VectorN VectorN::operator-(const VectorN& rhs)const
{
        VectorN res;
		if(vectorCapacity <= rhs.vectorCapacity )
			res.vectorCapacity = vectorCapacity;
		else
		res.vectorCapacity = rhs.vectorCapacity;

		res.vectorArr = new double[res.vectorCapacity];

        for(size_t i=0; i < res.vectorCapacity; i++)
        {
        res.vectorArr[i]= vectorArr[i] - rhs.vectorArr[i];
        }
        return res;
}


/***********************************************************
This funtion overloads the ostream creating two objects. The
first object is called lhs short for "Left Hand Side" and the
second is called rhs meaning "Right Hand Side." These objects
overload the commas and parentheses anytime the vector
outputs any number for the vector capacity and returns lhs.
***********************************************************/


ostream& operator<<(ostream& lhs, const VectorN &rhs)
{
	lhs << "(";

	for(size_t i = 0; i < rhs.vectorCapacity; i++)
	{
		lhs << rhs[i] << ",";
	}
	lhs << ")";
	return lhs;
}

/***************************************************
This is an overloaded copy assignment operator. This assigns
the object "other" to another VectorN object. This method
uses the pointer "this" to point to the addresses that
are using the contents in the vector capacity. This method
returns *this.
***************************************************/


VectorN& VectorN::operator=(const VectorN& other)
{

if( this ==&other )

return *this;

delete[] vectorArr;

vectorCapacity = other.vectorCapacity;
if(vectorCapacity == 0)
	vectorArr = nullptr;
else
	vectorArr = new double [other.vectorCapacity];

for(size_t i = 0; i < other.vectorCapacity; i++)

	vectorArr[i] = other.vectorArr[i];

return *this;


}


/*********************************************************
This method uses the multiplication operator to multiply
the vector array by anything on the right side of it.
It uses the *this pointer to find the stored addresses.
This method then returns the object objR.
*********************************************************/

VectorN VectorN::operator*(float right)const
{
	VectorN objR = *this;
	for(size_t i=0; i < objR.vectorCapacity; i++ )
	{
		objR.vectorArr[i]*= right;
	}

	return objR;
}

/********************************************************
The multiplication operator used in this method is used to
multiply the vector array object rhs by the floating point
called left. This will loop through multipling both sides and storing
the values into the object called objL and then return objL.

*********************************************************/

VectorN operator*(float left, const VectorN& rhs)
{
	VectorN objL = rhs;

	for(size_t i=0; i < objL.vectorCapacity; i++)
	{
		objL.vectorArr[i] *= left;
	}
	return objL;
}
/*********************************************************
This method uses the multiplication operator to multiply the left vector array
by the right vector array. This illustrates the length of numbers
in the vector capacity. This is then added into the object res,
and res is returned.
**********************************************************/

float VectorN::operator*(const VectorN& right)const
{
	double res = 0;
size_t limit=(vectorCapacity < right.vectorCapacity) ? vectorCapacity : right.vectorCapacity;

for(size_t i = 0; i < limit; i++)
res += vectorArr[i] * right.vectorArr[i];

return res;
}


/********************************************************
A bool is used for this method to compare two vectorNs
for each component in each array. If the vectorCapacity is not equal
to the rhs vectorCapacity it will return false, but if they
are both equal it will return true. Additionally the size_t loop
runs through the vectorCapacity and compares the two vectorArr's
to see if the array is the same and returns true if they are equal.
*********************************************************/

bool VectorN::operator==(const VectorN& rhs)const
{
	if(vectorCapacity!=rhs.vectorCapacity)
		{
		return false;
		}
		for(size_t i =0; i < vectorCapacity ; i++)
		{
			if(vectorArr[i] != rhs.vectorArr[i])
				return false; 
		}
	return true;
}

/********************************************************
The indexing operators are used to provide accessor methods
for the class. This reads and indexes through the vector array
and returns vectorArr.

*********************************************************/

double VectorN::operator[](int traceSub)const
{
	return vectorArr[traceSub];
}

/********************************************************
The indexing operator uses traceSub to index through the
vectorArr. This returns vectorArr.

*********************************************************/

double& VectorN::operator[](int traceSub)
{
	return vectorArr[traceSub];
}
/**********************************************************
This method is a variant of the read form of operator[] that
provides error checking. This error checking checks if the sub is less
or equal to the vector capacity then either throws an error message
or returns the subscript for the vector array.
**********************************************************/

double VectorN::at(int sub) const
{
	if (sub < 0 || sub >= (int)vectorCapacity)
	{
		throw out_of_range("subscript out of range");
	}
	else
		return vectorArr[sub];
}
/***********************************************************
This method is a variant of the write form of operator[] that
provides error checking. This error checking checks if the sub is less
or equal to the vector capacity then either throws an error message
or returns the subscript for the vector array.
************************************************************/
double& VectorN::at(int sub)
{
	if(sub < 0 || sub >= (int)vectorCapacity)
	{
		throw out_of_range("subscript out of range");
	}
	else
		return vectorArr[sub];

}



