/***********************************************************
CSCI 241 - Assignment 4 - Fall 2016

Progammer: Lukus Hendrix
Z-ID: z1761354
Section: 3
T.A: Karthik Kondagalla
Date Due: October 18, 2016

Purpose: This program illustrates and implements operator overloading.
This program manipulates 3 dimensional array vectors for floating point numbers
associated with the direction of x, y, and z.

************************************************************/

#include <iostream>
#include <iomanip>
#include "Vector3.h"
using namespace std;

/***********************************************************
This constructor takes three doubles x, y,and z.
Then creates an array of 3, declaring each component x, y, z,
in the order of 0, 1, and 2. These doubles have a predefined
default equal to 0.
***********************************************************/

Vector3::Vector3(double x, double y, double z)
{
	vector[0]=x;
	vector[1]=y;
	vector[2]=z;
}

/***********************************************************
This funtion overloads the ostream creating two objects. The
first object is called lhs short for "Left Hand Side" and the
second is called rhs meaning "Right Hand Side." These objects
overload the commas and parentheses everytime the vector
outputs the three components of x,y,z  and gives them
a ( x,y,z) format. It returns lhs.
***********************************************************/

ostream& operator << (ostream& lhs, const Vector3 &rhs)
{
	lhs<<"(";
	lhs<<rhs.vector[0]<<", ";
	lhs<<rhs.vector[1]<<", ";
	lhs<<rhs.vector[2]<<") ";

	return lhs;
}


/***********************************************************
This addition operator takes two Vector3s for arguments and creates the
objects lhs and rhs. Vector3 then creates an object of itself called res.
A for loop is established to loop the value of each component of x,y,z
in the vector[] array. The two objects lhs and rhs are then looped and
added together such as x+x, y+y, and z+z. This is overloaed into the
res object then the res object is returned.
***********************************************************/

Vector3 operator+(const Vector3& lhs, const Vector3& rhs)
{
	Vector3 res;

	for(int i=0; i < 3; i++)
	{
	res.vector[i]= lhs.vector[i] + rhs.vector[i];
	}
	return res;
}

/***********************************************************
The same method the addition operator used is also used for
the subtraction operator, except it uses subtraction and loops
the differences together, returing the x-x, y-y, z-z values
with the object res.
***********************************************************/

Vector3 operator-(const Vector3& lhs, const Vector3& rhs)
{
        Vector3 res;

        for(int i=0; i < 3; i++)
        {
        res.vector[i]= lhs.vector[i] - rhs.vector[i];
        }
        return res;
}

/***********************************************************
This multiplication operator is overloaded 3 times creating the
scalar product of 1. It multiplies the rhs vector array with
the first vector array to create a sum. The sum is stored and
returned in the float called result.
***********************************************************/

float Vector3::operator*(const Vector3& rhs)const
{
	float result = 0;
	result += (float)vector[0]*(float)rhs.vector[0];
	result += (float)vector[1]*(float)rhs.vector[1];
	result += (float)vector[2]*(float)rhs.vector[2];

	return result;
}

/*********************************************************
This operator declares a floating point constant called right.
The constant called right then multiplies the vector array by
looping through the first array of 1,2,3. The multiplication
is then stored inside the object called objR and returned.

*********************************************************/

Vector3 Vector3::operator*(float right)const
{
	Vector3 objR;
	for(int i=0; i < 3; i++ )
	{
		objR.vector[i] = vector[i]*right;
	}
	return objR;
}

/********************************************************
The multiplication operator used in this method is used to
multiply the vector array object rhs by the floating point
called left. This will loop then multiply both sides and store
it into the object called objL and then return objL.

*********************************************************/

Vector3 operator*(float left, const Vector3& rhs)
{
	Vector3 objL;

	for(int i=0; i < 3; i++)
	{
		objL.vector[i] = rhs.vector[i]*left;
	}
	return objL;
}

/********************************************************
A bool is used for this method to compare two vector3s
for each component in each array. If vectors are not equal
it will return false, but if they are both equal it will
return true.
*********************************************************/

bool Vector3::operator==(const Vector3& rhs)const
{
	for(int i=0; i < 3; i++)
	{
		if(vector[i]!=rhs.vector[i])
		{
		return false;
		}
	}
	return true;
}

/********************************************************
The indexing operators are used to provide accessor methods
for the class. This reads the vector array and returns a
double.

*********************************************************/

double Vector3::operator[](int traceSub)const
{
	return vector[traceSub];
}

/********************************************************
The indexing operator outputs the vector and returns a
double.

*********************************************************/

double& Vector3::operator[](int traceSub)
{
	return vector[traceSub];
}



