/***********************************************************
CSCI 241 - Assignment 8 - Fall 2016

Progammer: Luke Hendrix
Z-ID: Z1761354
Section: 3
TA:  Karthik Kondagalla
Date Due: November 22, 2016

Purpose: This header file uses templates to open, reads, and
print a series in items from the input file.
************************************************************/

#ifndef SORTS_H
#define SORTS_H

#include <fstream>
#include <iostream>
using namespace std;

/***************************************************************
Prototypes
Use: Specifies method's and function's for compiler use.

***************************************************************/

template <class T>
void buildList(vector<T>& set, const char* fileName);


template <class T>
void printList(const vector<T>& set, int itemWidth, int numPerLine);



template <class T>
bool lessThan(const T& item1, const T& item2);

template <class T>
bool greaterThan(const T& item1, const T& item2);



/***************************************************************
buildlist

Use: This method is used to open and read the fileName file
until the end. Then closes the file.
Parameters: 1. vector<T>& set, is the set of numbers and words
	    on the infile being read.
            2. fileName is the infile being read.
Returns: nothing
***************************************************************/

template <class T>
void buildList(vector<T>& set, const char* fileName)
{
T item;
   ifstream inFile;

	inFile.open(fileName);
	if(!inFile)
	{
		cout << "Cannot open file." << endl;
		exit(-1);
	}
	inFile >>item;
	while(!inFile.eof())
	{
	 set.push_back(item);
	inFile >> item;
	}
	inFile.close();

}


/***************************************************************
printlist
Use: This funtion enables the print method which goes through
the items using a loop printing each items width and size.
This uses modulus to seperate each line with an endl.

Parameters: 1. const vector<T>& set: A reference to a constant vector
	       that contains items to print.
            2. itemWidth: specifies a current occupation of an item.
	    3. numPerLine: Specifies a number that will be printed
	       per line.
Returns: nothing
***************************************************************/

template <class T>
void printList(const vector<T>& set, int itemWidth, int numPerLine)
{

	for(int i = 0; i < (int)set.size(); i++)
	{
		cout << setw(itemWidth) << set[i] << " ";

	if(i %  numPerLine == 0)
		cout << endl;

	}
	cout << endl;

}

/***************************************************************
bool lessThan
Use: Uses the data type T to compare item1 with item2.
     If item1 is less than item2 it returns true, else false.
Parameters: 1. item1: comparable object.
            2. items2: comparable object.
Returns: bool, true or false
****************************************************************/

template <class T>
bool lessThan(const T& item1, const T& item2)
{
	if(item1 < item2)
		return true;
	else
		return false;

}



/***************************************************************
bool greaterThan
Use: Uses the data type T to compare item1 with item2.
     If item1 is greater than item2 it returns true, else false.
Parameters: 1. item1: comparable object.
            2. items2: comparable object.
Returns: bool,  true or false
****************************************************************/


template <class T>
bool greaterThan(const T& item1, const T& item2)
{
	if(item1 > item2)
		return true;
	else
		return false;

}




#endif

