/***********************************************************
CSCI 241 - Assignment 8 - Fall 2016

Progammer: Luke Hendrix
Z-ID: Z1761354
Section: 3
TA:  Karthik Kondagalla
Date Due: November 22, 2016

Purpose: This H file applies a quick sort that partitions half
	 of the vector to sort.
************************************************************/

#ifndef QUICKSORT_H
#define QUICHSORT_H

/***************************************************************
Prototypes
Use: Specifies method's and function's for compiler use.

***************************************************************/

template <class T>
void quickSort(vector<T>& set, bool (*compare)(const T&, const T&));

template <class T>
void quickSort(vector<T>& set, int, int, bool (*compare)(const T&, const T&));

template <class T>
int partition(vector<T>& set, int, int, bool (*compare)(const T&, const T&));


/***************************************************************
quickSort
Use: Calls a recursive quick sort function.

Parameters: 1. vector<T>& set: Reference to a vector containing items to sort.
            2. *compare: A pointer to a comparison function used to compare
	       to items of the template type T.
Returns: void,  nothing
****************************************************************/

template <class T>
void quickSort(vector<T>& set, bool (*compare)(const T&, const T&))
{
quickSort(set, 0, set.size()-1, compare);

}



/***************************************************************
quickSort
Use: performs recursive call to implement the quick sort algorithm.

Parameters: 1. vector<T>& set: Reference to a vector containing items to sort.
            2. start: An integer that holds the starting vector item.
            3. end: An integer that holds the ending vector item.
	    4. *compare: A pointer to a comparison function used to compare
               to items of the template type T.
Returns: void,  nothing
****************************************************************/


template <class T>
void quickSort(vector<T>& set, int start, int end, bool (*compare)(const T&, const T&))
{
 int pivotPoint;

   if (start < end)
      {
      pivotPoint = partition(set, start, end, compare);     // Get the pivot point
      quickSort(set, start, pivotPoint - 1, compare);       // Sort first sublist
      quickSort(set, pivotPoint + 1, end, compare);         // Sort second sublist
      }

}



/***************************************************************
partition

Use: select a pivot element, then partitions the vector around
     the pivot. It creates a temp variable to store the values
     from the starting point on the vector to swap places with
     the middle point. This function then uses a loop to scan
     through the pivotIndex by swapping scan with pivot index.

Parameters: 1. vector<T>& set: Reference to a vector containing items to sort.
            2. start: An integer that holds the starting vector item.
	    3. end: An integer that holds the ending vector item.
	    4. *compare: A pointer to a comparison function used to compare
               two items of the template type T.

Returns: pivotIndex
****************************************************************/


template <class T>
int partition(vector<T>& set, int start, int end, bool (*compare)(const T&, const T&))
{
  int pivotIndex, mid;
   T pivotValue, temp;

   mid = (start + end) / 2;


	temp = set[start];
	set[start] = set[mid];
	set[mid] = temp;


   pivotIndex = start;
   pivotValue = set[start];

   for (int scan = start + 1; scan <= end; scan++)
      {
      if (compare(set[scan], pivotValue))
         {
         pivotIndex++;
          temp = set[pivotIndex];
        set[pivotIndex] = set[scan];
        set[scan] = temp;

         }
      }
	temp = set[start];
        set[start] = set[pivotIndex];
        set[pivotIndex] = temp;


   return pivotIndex;

}


#endif
