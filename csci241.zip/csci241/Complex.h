#ifndef COMPLEX_H
  #define COMPLEX_H

class Complex
  {
  public:
    Complex();
    Complex(int, int);

    Complex add( int, int );

    void print();

  private:
    int real, imag;
  };

#endif
