#ifndef DYNAMICARRAY_H
  #define DYNAMICARRAY_H
#include <iostream>
using std::ostream;
using std::istream;

class dynamicArray
  {
  friend ostream & operator<<( ostream &, const dynamicArray & );
  friend istream & operator>>( istream &, dynamicArray & );

  friend dynamicArray operator+( const int &, const dynamicArray & );

  public:
    dynamicArray( int = 20 );
    dynamicArray( const dynamicArray & );

    ~dynamicArray();

    dynamicArray & operator=( const dynamicArray & );

    void addItem( int );

    void print() const;

    dynamicArray operator+( const int & ) const;  //dynamicArray + int

    //read version
    int operator[]( const int & ) const;

    //write version
    int & operator[]( const int & );

  private:
    int capacity;
    int numVals;
    int *data;
  };
#endif
