#include <iostream>
#include <iomanip>
#include <cassert>
#include <cstdlib>
#include <ctime>

#include "dynamicArray.h"

using std::cout;
using std::endl;
using std::cin;


int main()
{
dynamicArray d;

srand( 1 );

for( int cnt = 1; cnt <= 10; cnt++ )
  {
  int randomNumber = rand();

  d.addItem( randomNumber );
  }

//d.print();

cout << d << endl;

//cin >> d;

//cout << d << endl;


//dynamicArray d2;

//d2 = d + 7;

//cout << endl << endl << d2 << endl;


//d2 = 2 + d;

//cout << endl << endl << d2 << endl;

cout << "Read version: " << d[4] << endl << endl;

d[4] = 42;

cout << d << endl;


return 0;
}
