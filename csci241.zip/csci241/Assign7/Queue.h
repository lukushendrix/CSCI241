/***********************************************************
  CSCI 241 - Assignment 7 - Fall 2016
  Progammer: Luke Hendrix
  Z-ID:      Z1761354
  Section:   3
  T.A:       Karthik Kondagalla
  Date Due:  November 15, 2016

	Purpose: The purpose of this program is to create a template
	implementing the queue ADT using a singly linked list.

************************************************************/

#ifndef QUEUE_H
#define QUEUE_H

#include <iostream>
#include <stdexcept>
#include <cstdlib>
using namespace std;
using std::ostream;

/**************************************************************
This template has two data members, the first one is a pointer to
the Node called next, and the second one is a member of the template
parameter which stores an item called T data to be inserted into the
queue. The pointer next will be set to a null if it is the
the last node on the list.
***************************************************************/

template <class T>
struct Node
   {
	Node<T>* next;
	T data;

	Node(const T& = T(), Node<T>* next = nullptr);
   };

/**************************************************************
This is the constructor of the struct Node, and takes an argument
that is a reference to the const "data". This constructor copies the
argument into the queue Node, forming newData and newNext.
***************************************************************/

template <class T>
Node<T>::Node(const T& newData, Node<T>* newNext)
{
	data = newData;
	next = newNext;

}


/**************************************************************
This forwards and prototypes the declaration of the Queue template class.
***************************************************************/

template <class T>
class Queue;

/*********************************************************************
This forwards and prototypes the declaration of the operator << template
function.
**********************************************************************/
template <class T>
std::ostream& operator<<(std::ostream&, const Queue<T>&);


/*********************************************************************
This is the friend declaration for the ostream operator. This also contains
all of the methods for public. The private data members are pointers to
the front node and the back node in the queue. qSize is to keep track of the
number of items stored in the queue.
**********************************************************************/
template <class T>
class Queue
   {
   friend std::ostream& operator<< <>(std::ostream&, const Queue<T>&);

  public:
	Queue();
	~Queue();
	void copyList(const Queue<T>&);
	Queue(const Queue<T>&);
	Queue& operator=(const Queue<T>&);
	void clear();
	size_t size() const;
	bool empty() const;
	const T& front() const;
	const T& back() const;
	void push(const T& );
	void pop();

private:
	Node<T> *qFront;
	Node<T> *qBack;
	size_t qSize;
   };

/*********************************************************************
This is the default constructor for the Queue class. It takes no arguments
and sets the front and back private data members to null pointers.
This also sets the size of the queue to zero.
**********************************************************************/

template <class T>
Queue<T>::Queue()
{
	qFront = nullptr;
	qBack = nullptr;
	qSize = 0;
}

/*********************************************************************
This destructor calls the clear method to free space.
**********************************************************************/

template <class T>
Queue<T>::~Queue()
{
	clear();
}

/*********************************************************************
This is a copy constructor that sets the queue's front and back to a
null pointers and size to zero. This also calls the copy list method to
copy the linked list into the node object.
**********************************************************************/

template <class T>
Queue<T>::Queue(const Queue<T>& other)
{
	qFront = nullptr;
	qBack = nullptr;
	qSize = 0;
	copyList(other);

}


/*********************************************************************
This assignment operator is overloaded by using the object "other" and
makes sure it is not deleted in the process. It uses the if statement
to check the parameter then clears and calls the copy list function,
which then returns the pointer *this.
**********************************************************************/

template <class T>
Queue<T>& Queue<T>::operator=(const Queue<T>& other)
{
	if(this != &other)
	{
		clear();
		copyList(other);
	}
	return *this;

}

/*********************************************************************
This method copies and assigns the list to a pointer that points to
the struct Node. This uses a for loop so it can loop to the next node on the
list if it is not a null pointer. Then it uses the push method to push
new data to the last node.
***********************************************************************/
template <class T>
void Queue<T>::copyList(const Queue<T>& other)
	{
	Node<T>* ptr;
	for(ptr = other.qFront; ptr != nullptr; ptr = ptr->next)
	push(ptr->data);
	}

/*********************************************************************
This operator overloads the ostream. This uses a for loop
to output the next item in the queue from right to left. This operator
returns the left object called lObj.
**********************************************************************/

template <class T>
ostream& operator<<(ostream& lObj, const Queue<T>& rObj)
{
	Node<T>* ptr;

	for(ptr = rObj.qFront; ptr != nullptr; ptr = ptr->next)
		lObj << ptr->data << ' ';
	return lObj;
}

/*********************************************************************
This is the clear method and uses a while loop to verify that the
size of the queue is not zero, then calls the pop method.
**********************************************************************/

template <class T>
void Queue<T>::clear()
{
	while(qSize != 0)
		pop();

}

/*********************************************************************
This is the size method. It is a constant and returns the queue size.

**********************************************************************/

template <class T>
size_t Queue<T>::size()const
{
	return qSize;
}

/*********************************************************************
This method uses a bool to check if the queue is empty or not. It returns
true if it is empty, or else it returns false.
**********************************************************************/

template <class T>
bool Queue<T>::empty()const
{
	if(qSize == 0)
		return true;
	else
		return false;

}


/*********************************************************************
This method throws an underflow error if the queue is empty, or else
it returns the data stored in the front node of the queue.
**********************************************************************/

template <class T>
const T& Queue<T>::front()const
{
	if(empty())
	{
	throw underflow_error("Queue underflow on front()");
	}
	else
		return qFront->data;
}

/*********************************************************************
This method throws an underflow error if the queue is empty, or else
it returns  the data stored in the back node of the queue.
**********************************************************************/

template <class T>
const T& Queue<T>::back()const
{
        if(empty())
        {
        throw underflow_error("Queue underflow on back()");
        }
        else
                return qBack->data;
}

/*********************************************************************
This method takes a reference to a constant item to insert into the
queue. This method checks if queue is empty and if empty assigns the
front of the queue to a new node otherwise it increments the queue size
by inserting a new item to the back of the queue.
**********************************************************************/

template <class T>
void Queue<T>::push(const T& item)
{
Node<T>* newNode= new Node<T>(item);
	if(empty())
		qFront = newNode;
	else
		qBack->next = newNode;
		qBack = newNode;
		qSize++;
}

/*********************************************************************
This method has no arguments and returns void. The pop method then calls
an overflow error if the queue is empty. However, this method decrements
the front of the queue and reassigns the null pointer to the back of the
queue.
**********************************************************************/

template <class T>
void Queue<T>::pop()
{
	if(empty())
	{
		throw underflow_error("Queue underflow on pop()");
	}
	Node<T>* delNode = qFront;
	qFront = qFront->next;

	if(qFront == nullptr)
		qBack = nullptr;
		delete delNode;
		qSize--;
}




#endif

