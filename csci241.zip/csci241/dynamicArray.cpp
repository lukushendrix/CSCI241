//The methods are coded in this file.
#include <iostream>
#include <iomanip>
#include <cassert>

#include "dynamicArray.h"

using std::cout;
using std::endl;
using std::setw;


dynamicArray::dynamicArray( int initialCap )
{
capacity = initialCap;

numVals = 0;

data = new int[ capacity ];
assert( data != 0 );

for( int sub = 0; sub < capacity; sub++ )
  data[sub] = 0;
}



dynamicArray::~dynamicArray()
{
delete [] data;
}



dynamicArray::dynamicArray( const dynamicArray &existingArray )
{
capacity = existingArray.capacity;

numVals = existingArray.numVals;


data = new int[ capacity ];
assert( data != 0 );

for( int sub = 0; sub < capacity; sub++ )
  data[sub] = existingArray.data[sub];
}



dynamicArray & dynamicArray::operator=( const dynamicArray &rightArray )
{
if( this != &rightArray )
  {
  capacity = rightArray.capacity;

  numVals = rightArray.numVals;

  delete [] data;

  data = new int[ capacity ];
  assert( data != 0 );

  for( int sub = 0; sub < capacity; sub++ )
    data[sub] = rightArray.data[sub];
  }

return *this;
}



void dynamicArray::addItem( int item )
{
data[numVals] = item;
numVals++;
}



void dynamicArray::print() const
{
for( int sub = 0; sub < numVals; sub++ )
  {
  if( sub % 5 == 0 )
    cout << endl;

  cout << setw(15) << data[sub];
  }

cout << endl;
}





//output operator

ostream & operator<<( ostream &leftObj, const dynamicArray &rightObj )
{
for( int sub = 0; sub < rightObj.numVals; sub++ )
  {
  if( sub % 5 == 0 )
    leftObj << endl;

  leftObj << setw(15) << rightObj.data[sub];
  }

return leftObj;
}




istream & operator>>( istream &leftObj, dynamicArray &rightObj )
{
int numValues;

leftObj >> numValues;

int num, cnt;
for(  cnt = 1; cnt <= numValues; cnt++ )
  {
  leftObj >> num;
  rightObj.addItem( num );
  }

return leftObj;
}





//int + dynamicArray

dynamicArray operator+( const int&leftObj, const dynamicArray &rightObj )
{
dynamicArray result = rightObj;

for( int sub = 0; sub < rightObj.numVals; sub++ )
  {
  result.data[sub] = leftObj + result.data[sub];
  }

return result;
}



//dynamicArray + int

dynamicArray dynamicArray::operator+( const int &rightObj ) const
{
dynamicArray result = *this;

for( int sub = 0; sub < numVals; sub++ )
  {
  result.data[sub] = result.data[sub] + rightObj;
  }

return result;
}




//read version

int dynamicArray::operator[]( const int &sub ) const
{
return data[sub];
}

//write version
int & dynamicArray::operator[]( const int &sub )
{
return data[sub];
}






