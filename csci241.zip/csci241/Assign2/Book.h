#ifndef BOOK_H
   #define BOOK_H

   //*****************************************************************
   // FILE:      Book.h
   // AUTHOR:    Luke Hendrix
   // LOGON ID:  z1761354
   // DUE DATE:  09/20/16
   //
   // PURPOSE:   Contains the declaration for the book class.
   //*****************************************************************

   class Book
      {
      public:
        Book() ;
        Book(char*,char*, double, int );

        void print();
	char* getISBN();
        char* getTitle();
        double getPrice();
        int getQuantity();
        void setPrice(double);
        void setQuantity(int);
        int fulfillOrder(int);


private:
	char bISBN[11];
	char title[41];
double price;
int quantStock;

};

   #endif

