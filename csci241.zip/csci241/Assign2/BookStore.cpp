//*****************************************************************
   // FILE:      BookStore.cpp
   // AUTHOR:    Luke Hendrix
   // LOGON ID:  z1761354
   // DUE DATE: 09/20/2016
   /*
   PURPOSE: The purpose for this file is to hold functions and methods 
	that iterate through a Book Class. The file stores the logic and
	functions necessary to read and open other files that present
	 this program.
   *****************************************************************/


#include <iostream>
#include "BookStore.h"
#include <fstream>
#include <cstring>
#include <iomanip>

using namespace std;

//this  creates the scope to the bookstore class to bookstore function.
BookStore::BookStore()
{
	BookQuant = 0;
}
//this uses filestream to open and read the size of the bookstore
//class in binary.
BookStore::BookStore(const char* file)
{
	ifstream inFile;
	inFile.open(file, ios::binary);
	inFile.read((char*) this, sizeof(BookStore));
	inFile.close();
	sortByISBN();

}
// this calls the print method to iterate through the book array.
void BookStore::print()
{
	cout << "Book Inventory List" << endl;
	cout << setw(14) << left<< "ISBN" << left << setw(44)<< "Title"<< right<<setw(5)<< "Price" << setw(6)<<"Qty." << endl; 

	for(int a = 0; a < ( BookQuant -1) ; a = a+1 )
	{
		BookArray[a].print();
		cout << endl;
	}
}

//this uses a scope to the search for ISBN funtcion to
// compare and sort the array.

void BookStore::sortByISBN()
{
	int i, j;
	Book Bucket;

	for (i = 1; i < BookQuant; i++)
	{
		Bucket = BookArray[i];

		for (j = i; (j > 0) && (strcmp(BookArray[j-1].getISBN(), Bucket.getISBN()) > 0); j--)
			BookArray[j] = BookArray[j-1];

		BookArray[j] = Bucket;
	}
}
//this also uses a scope to the search for ISBN funtcion to
// compare and sort the array.
int BookStore::searchForISBN(char searchISBN[])
{
	int low = 0;
	int high = BookQuant - 1;
	int mid;

	while (low <= high)
	{
		mid = (low + high) / 2;

		if ((strcmp(searchISBN, BookArray[mid].getISBN() )) == 0)
			return mid;

		if ((strcmp(searchISBN, BookArray[mid].getISBN())) < 0)
			high = mid - 1;
		else
			low = mid + 1;
	}

	return -1;
} 
//this declares orderRecords as a constant char
//this has no return type and prints the search for isbn 
// orderNumber, numShipped, and isbn on screen.
void BookStore::processOrders(const char* orderRecords)
{
	ifstream inFile;
	char orderNumber[7];
	char isbn[11];
	int orderQuantity;
	int numShipped;

	inFile.open(orderRecords);

	cout <<"Order Listing" << endl << endl;

	if ( inFile.is_open());
	{
		inFile >> orderNumber;

		while (!inFile.eof())
		{

			inFile >> isbn;
			inFile >> orderQuantity;

			int index = searchForISBN(isbn);
			if (index == -1)
			{   // print error message
				cout << "Order_#" << orderNumber << ": Error - ISBN ";
				cout << isbn << " Does not exist. " << endl;
			}
			else
			{ numShipped = BookArray [index].fulfillOrder(orderQuantity);
			cout << "Order # " << orderNumber << ":ISBN " << isbn;
			cout << ", " << numShipped << " of " << orderQuantity;
			cout << "shipped, order total $" << (numShipped *BookArray [index].getPrice()) << endl;
			}

			inFile >> orderNumber;
		}

	}


}
