#include "Book.h"
#include <iostream>
#include <iomanip>
#include <cstring>
#include "string.h" 

using std::strcpy;

using namespace std;


Book::Book()
{

	strcpy(bISBN, "");
	strcpy(title, "");
quantStock = 0;
price = 0;


}

Book::Book(char* newISBN , char* newTitle, double newPrice, int newQuantity)
{
strcpy( bISBN, newISBN);
 strcpy( title,  newTitle);

setPrice(newPrice);
setQuantity(newQuantity);
}

void Book::setPrice(double newPrice)
{
if (newPrice>=0)
price = newPrice;

else
price = 0;
}

void Book::setQuantity(int newQuantity)
{
if (newQuantity >= 0)
quantStock =  newQuantity;

else
quantStock = 0;
}

int Book::fulfillOrder(int orderQuantity)
{

	int shipped;

if (orderQuantity < 0)

	cout << "Error, order can not be filled." << endl;

else if (orderQuantity<= quantStock )
{
	shipped = orderQuantity;
	quantStock -= shipped;
}
else
{
	shipped = quantStock;
	quantStock = 0;
}

return shipped;

}

char* Book::getTitle()
{
return title;
}
char* Book::getISBN()
{
return bISBN;
}

double Book::getPrice()
{
return price;
}

int Book::getQuantity()
{
return quantStock;
}


void Book::print()
{


	cout << setw(14)<<left << bISBN <<  left << setw(44)<< title << right <<  setw(5) << fixed << setprecision(2) << price <<  setw(6) <<  quantStock ;
}




