
//**************
//*CSCI  - Fall  
//*Lukus Hendrix 
//*
//*Lab Training Exercise
//*******************

#include <iostream>
using std::cin;
using std::cout;
using std::endl;

int main() { char name[10]; cout << "What is your first name?";
 cin >> name; cout<< "Hello,"<< name << endl; return 0; }




